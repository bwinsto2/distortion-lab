# Lab setup: Linux desktop, mirror stereoscope, knobs and buttons

## Hardware

- **Stereoscope monitor:** the monitor viewed through the mirror stereoscope. Each eye sees one half of it.
- **Researcher monitor:** a second monitor for the console. Set the displays to **extended** ("join displays"), not mirrored.
- **USB MIDI controller with endless knobs and buttons**, for example a Behringer X-Touch Mini. Ordinary knobs that
  stop at the ends also work, but their value can jump when the app changes a setting by itself (Undo, choosing an
  alternative). Until it arrives, the keyboard does everything (see below).

## One-time software setup (Linux)

1. Install Google Chrome or Chromium if it isn't there. Chrome is needed for the MIDI controller.
2. Get the app (once):
   ```bash
   cd ~ && git clone https://github.com/bwinsto2/distortion-lab.git
   ```
3. Add menu and desktop launchers:
   ```bash
   cd ~/distortion-lab && sh tools/install_linux_launcher.sh
   ```
4. Optional, for AI suggestions on your Claude plan: install Claude Code (`curl -fsSL https://claude.ai/install.sh | bash`),
   then run `claude` once and sign in with your Claude account (see [AI_BRIDGE.md](AI_BRIDGE.md)).

The launchers run `git pull` first, so the computer always runs the latest version. To open the app in Chrome when it
isn't the default browser, start it from a terminal with `BROWSER=google-chrome ./start.sh` (or `chromium`).

## Each session

1. Start **Distortion Lab** (or **Distortion Lab (with Claude)**) from the applications menu or desktop.
2. In the browser, enter the **participant ID, session and amblyopic eye**. The reference grating goes to the amblyopic
   eye's half of the stereoscope screen and the reconstruction to the fellow eye's half.
3. Click **Open stimulus window**, drag it onto the stereoscope monitor and press **F** for fullscreen.
4. Check the alignment and size through the stereoscope (Experimenter tab → optics: separation, vertical offset,
   diameter, px/°).
5. Experimenter tab → **Participant controls on**.

## What the participant sees and does

| | Amblyopic-eye half | Fellow-eye half |
|---|---|---|
| **Amblyopic eye** view | reference grating | plain mid-grey |
| **Fellow eye** view | plain mid-grey | reconstruction, with a small dim menu below it (never over the grating) |
| **Both** | reference grating | reconstruction (or, in Choose, the ring of options around an empty centre where the test grating fuses) |

The **Switch eye** button cycles amblyopic → fellow → both. Participant controls start in **Choose** with both eyes.

- **Choose mode (first step):** 8 starting pictures are shown in a ring in the fellow-eye half, around an empty centre.
  With both eyes, the amblyopic eye's test grating appears in that centre, so each option can be compared with it
  directly, as in Maruya et al.'s dichoptic display. Turning moves the highlight clockwise and onto the next page of 8
  after the last one (the second knob or ↑/↓ jumps a page). Pressing chooses and moves on to Adjust. The library is
  ordered: unchanged grating, the 7 plaid types, the feature families (mild and strong), combinations, then
  **None of these**, which records that response and sends the researcher to the description tab.

Blank halves stay at the same mid-grey as the background, so switching doesn't cause flashes.

- **Adjust mode:** the menu shows the highlighted control (e.g. "Bend amount", with a bar) and, faintly, the controls
  before and after it. Turning the knob changes it live; pressing the knob moves to the next control. Fixed (pinned)
  controls say "(fixed)". The list is the same as the console's Adjust tab, so the researcher can add a feature there
  (e.g. "+ Gap") and it appears in the participant's list.
- **Compare mode:** turning the knob flips the grating itself through the current version and versions A–D, all in the
  same place. Pressing the knob chooses the one showing. **New alternatives** makes a new set close to the current
  version; repeated presses get closer each time. Suggestions from the AI bridge arrive here too.

| Control | Action |
|---|---|
| Main knob, turn | change the value (Adjust) / flip through versions (Compare) |
| Main knob, press | next control (Adjust) / choose (Compare) |
| Button | Switch eye: amblyopic → fellow → both |
| Button | Mode: Choose → Adjust → Compare |
| Button | New alternatives |
| Button | Undo |
| Optional second knob | choose which control (Adjust) |

**Setting up the controller:** Experimenter tab → **Connect MIDI controller** (allow MIDI when the browser asks) →
**Set up buttons and knobs…**, then follow the steps: turn or press each control once. The setup is remembered on that
computer. For the X-Touch Mini, use its **MC mode** (the "MC" button), where the knobs send relative turns.

**Mouse** (no extra hardware): in the stimulus window, scroll = knob (Shift+scroll = 5 clicks), left click = press,
**hold** left button about 1 s = new alternatives, right click = switch eye, middle click (press the wheel) =
next mode (Choose / Adjust / Compare), side "back" button = undo, side "forward" button = new alternatives. The first click locks the pointer
to the stimulus window (it's hidden) so the wheel keeps working. **Esc** releases it. Note that the computer has one
pointer: while it's locked, the researcher must press Esc before using the console with the mouse (a second mouse
moves the same pointer). The MIDI controller doesn't have this limitation.

**Keyboard** (works in the console outside text boxes, and in the stimulus window):
← → turn the knob (Shift = 5 clicks) · ↑ ↓ choose control · Enter = press knob · Space = switch eye ·
M = mode (Choose / Adjust / Compare) · N = new alternatives · Z = undo.

## The researcher's part (console)

The researcher types the participant's description while they talk (*Still different?* tab), can ask for AI
suggestions, add a feature type, pin something, record the outcome, and sees everything the participant sees in the
stimulus preview. Optics, eye routing and calibration are kept when the form changes.

## Nulling

Console → **Nulling** tab: choose the eye to adjust, what it's compared against (a straight grating in the other eye,
or nothing) and the starting point, then **Start nulling**. In the stereoscope the adjustable picture appears in that
eye's half, with the menu below it (larger text when it's the amblyopic eye). The participant uses the same knob,
mouse or keys (Adjust ↔ Compare) until it looks straight. Record the result, optionally run the other-eye check, then
**Repeat** (the starting point alternates) or **End nulling** to go back to matching.

Note on viewing with both eyes: in a mirror stereoscope the two halves are seen in the same direction, so the two
eyes' pictures overlap and can rival. Switching eyes, or nulling against nothing, avoids that.

## Fusion box, nonius fixation and alignment (from the lab battery)

These copy `FixBorders()` in `Functions_BinocularBattery.py` and the per-eye rotation in `BinocularDisplay.py`.

**The display**
- Each eye's half shows the same **15° × 15° viewing area** framed by **0.5° black/white border pieces**: 4 per
  horizontal side, 5 per vertical side, corners empty.
- The boxes are centred **±9°** from the middle of the screen (the battery's 18° border separation).
- **Nonius fixation:** a **horizontal bar for the left eye** and a **vertical bar for the right eye** (2° × 0.2°), each
  with a **1°-radius circle** touching the bar ends. When fused and aligned, this looks like one circle with a centred cross.
- Each eye's image is clipped to its own half of the screen, and can be rotated about its box centre.

**Side by side:** inside the box, the test grating sits **3° left of fixation** in the amblyopic eye's half, and the
match **3° right** in the fellow eye's half. After fusion they appear next to each other, so nothing overlaps or
rivals. Offset and side are settings in the Experimenter tab. In Choose mode, the test sits on the fixation point with
the ring of options around it.

**Alignment** runs automatically after a new session starts, and can be rerun from the Experimenter tab with
**Run alignment**. The participant uses the battery's keys:

| Key | Action |
|---|---|
| ← → | move the boxes apart / together (0.05°) |
| ↑ ↓ | right box up, left box down / the reverse (0.05°) |
| 4 / 6 | lower the left / right eye's contrast (an aid; it restores the other eye first) |
| L / R | select the left / right image |
| 7 / 9 | rotate the selected image 1° counter-clockwise / clockwise |
| 0 | reset position, contrast and both rotations |
| Enter | accept |

The keys work in the console (outside text boxes) and in the stimulus window. In the stimulus window the mouse also
works: scroll moves the boxes apart or together, Shift+scroll moves them vertically, and a click accepts. Each
accepted alignment is logged with all its values. The result carries over to the next session's layout.

**Screen size:** the boxes need about 34° of screen width. Set **pixels per degree** for your monitor and viewing
distance (Experimenter tab → calculator); the app warns if a box doesn't fit its half. For reference, the battery
used a 4K screen at 100 cm, about 110 px/°.

With the fusion box off, the app uses the earlier layout (centre separation % and right-panel vertical offset).
